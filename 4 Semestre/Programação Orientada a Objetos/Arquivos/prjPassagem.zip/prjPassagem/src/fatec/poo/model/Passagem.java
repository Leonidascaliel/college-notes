package fatec.poo.model;

/**
 *
 * @author Fatec
 */
public class Passagem {
    private int numero;
    private double preco;
    private int poltrona;
    private char tipo; //C - comum E - Estudante I - Idoso

    public Passagem(int numero) {
        this.numero = numero;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public void setPoltrona(int poltrona) {
        this.poltrona = poltrona;
    }

    public void setTipo(char tipo) {
        this.tipo = tipo;
    }

    public int getNumero() {
        return numero;
    }

    public double getPreco() {
        return preco;
    }

    public int getPoltrona() {
        return poltrona;
    }

    public char getTipo() {
        return tipo;
    }
    
    public double calcValorPagar(){
        double valPag;
        
        if (tipo == 'C' || tipo == 'c'){
            valPag = preco;
        }else
           if (tipo == 'E' || tipo == 'e'){
               valPag = preco - 0.15 * preco;
           }else{
               valPag = preco - 0.25 * preco;
           }
        
        return(valPag);
    }        
}
